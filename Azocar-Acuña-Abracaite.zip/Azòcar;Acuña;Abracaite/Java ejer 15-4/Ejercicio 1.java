/*
	Ejercicio 1
*/
		import java.util Scanner;

		public class Ejercicio1
							{
                             public static void main(String[]ar){
                             	Scanner teclado = new Scanner(System.in);
                             	 int num1;
                                 int num2;
                                 int resultado;
                                    System.out.print("Ingresa el primero numero:");
                                    num1=teclado.nextint();
                                    System.out.print("Ingresa el segundo numero:");
                                    num2=teclado.nextint();
                                    suma=num1+num2;
                                    resta=num1-num2;
                                    multi=num1*num2;
                                    divid=num1/num2;
                                    System.out.print("Suma:"+suma);
                                    System.out.print("Resta:"+resta);
                                    System.out.print("Division:"+divid);
                                    System.out.print("Multiplicacion:"+multi);
                                    }
                             }
							}