/*
	Ejercicio 3
*/
		import java.util Scanner;

		public class Ejercicio3
							{
                             public static void main(String[]ar){
                             	Scanner teclado = new Scanner(System.in);
                             	 int horas;
                                 int dias;
                                 int horas_mes;
                                 int sueldo;                             
                                    System.out.print("Ingresa horas trabajadas en el dia:");
                                    horas=teclado.nextint();
                                    System.out.print("Ingresa dias trabajados al mes:");
                                    dias=teclado.nextint();
                                    horas_mes=horas*dias;
                                    System.out.print("Horas en un mes:"+horas_mes);
                                    sueldo=400*horas_mes;
                                    System.out.print("Sueldo mensual: $"+sueldo);

                                    }
                             }
							}