/*
	Ejercicio 2
*/
		import java.util Scanner;

		public class Ejercicio2
							{
                             public static void main(String[]ar){
                             	Scanner teclado = new Scanner(System.in);
                             	 int num1;
                                 int num2;
                                 string nombre;
                                 float promedio;
                                    System.out.print("Ingresa el nombre:");
                                    nombre=teclado.nextint();
                                    System.out.print("Ingresa la primera nota:");
                                    nota1=teclado.nextint();
                                    System.out.print("Ingresa la segunda:");
                                    nota2=teclado.nextint();
                                    System.out.print("Ingresa la tercera:");
                                    nota3=teclado.nextint();
                                    suma=nota1+nota2+nota3;
                                    promedio=suma/3;
                                    System.out.print("Promedio del alumno:"+nombre);
                                    System.out.print("Promedio :"+promedio);
                                    }
                             }
							}